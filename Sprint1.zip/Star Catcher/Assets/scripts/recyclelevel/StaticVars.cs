﻿

    public class StaticVars
    {

        public static float distance = 4;
        public static float nextSectionPosition = 12;


    }

