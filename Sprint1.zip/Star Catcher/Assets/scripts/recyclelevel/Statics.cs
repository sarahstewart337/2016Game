﻿
public class statics
{
	public static float distance = 47.9f;
	public static float nextPosition = 239.6f;    
}
